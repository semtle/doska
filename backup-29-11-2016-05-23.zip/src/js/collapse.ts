function menuToggle(element: string){
    document.querySelector(element).classList.toggle('active');
}